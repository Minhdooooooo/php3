<?php $__env->startSection('title', 'Tin trong loai'); ?>

<?php $__env->startSection('content'); ?>
    <h2 class="news-title">TIN TRONG LOAI <?php echo e($tenLoai); ?></h2>
    <p class="meta">Loai ID: <?php echo e($idLoai); ?></p>

    <?php if($data->isEmpty()): ?>
        <p class="empty">Khong co tin nao trong loai nay.</p>
    <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="news-item">
                <h3 class="news-title">
                    <a href="<?php echo e(route('tin.chitiet', ['id' => $tin->id])); ?>"><?php echo e($tin->tieuDe); ?></a>
                </h3>
                <p class="summary"><?php echo e($tin->tomTat); ?></p>
                <p class="meta">Ngay dang: <?php echo e($tin->ngayDang); ?></p>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.news', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lap2\resources\views\tintrongloai.blade.php ENDPATH**/ ?>